JISAN VOICE PRO — Android starter project

এই ZIP-এ Android Studio-তে খোলার মতো Kotlin starter project আছে।

এখন যা আছে:
- Microphone permission
- Robot / Deep / Monster / Baby / Cartoon নামে সাধারণ অডিও ইফেক্ট ডেমো
- Start / Stop
- ফোনের স্পিকার বা হেডফোনে প্রসেস করা অডিও শোনানো

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এটি এখনো APK নয়; এটি source project।
- এই ডেমো পরিবর্তিত অডিও Free Fire-এর in-game microphone-এ পাঠায় না।
- Android-এর সাধারণ third-party app অন্য অ্যাপের mic input প্রতিস্থাপন করতে পারে না।
- সেলিব্রিটির আসল/অনুমতিহীন voice clone নেই; ভবিষ্যতে অনুমতিপ্রাপ্ত বা স্পষ্ট AI-generated voice যোগ করতে হবে।
- হেডফোন ব্যবহার করো; স্পিকারে feedback/শিসের শব্দ হতে পারে।

APK বানাতে:
1. Android Studio-তে project folder open করো।
2. Gradle sync শেষ হতে দাও।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করো।
4. build/app/outputs/apk/debug/app-debug.apk ফাইলটি পরীক্ষার APK।

Code on the Go-তে Android Gradle project build সমর্থিত নাও হতে পারে।
