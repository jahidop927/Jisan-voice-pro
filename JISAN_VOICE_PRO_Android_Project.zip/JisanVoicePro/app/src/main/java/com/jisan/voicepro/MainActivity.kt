package com.jisan.voicepro

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.AudioManager
import android.os.Bundle
import android.widget.*
import android.view.ViewGroup
import android.graphics.Color
import android.content.Context
import kotlin.concurrent.thread
import kotlin.math.*

class MainActivity : Activity() {
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    @Volatile private var running = false
    @Volatile private var selected = "Robot"
    private val sampleRate = 22050
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(25, 20, 48)
        window.navigationBarColor = Color.rgb(25, 20, 48)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(17, 16, 34))
        }
        val title = TextView(this).apply {
            text = "JISAN VOICE PRO"
            textSize = 27f; setTextColor(Color.WHITE); setPadding(0, 0, 0, 8)
        }
        val subtitle = TextView(this).apply {
            text = "LIVE VOICE EFFECTS • AUDIO DEMO"
            textSize = 12f; setTextColor(Color.rgb(190, 160, 255))
        }
        status = TextView(this).apply {
            text = "Status: Ready"
            textSize = 16f; setTextColor(Color.WHITE); setPadding(0, 26, 0, 18)
        }
        val label = TextView(this).apply {
            text = "Choose a voice effect"
            textSize = 16f; setTextColor(Color.WHITE); setPadding(0, 12, 0, 8)
        }
        val spinner = Spinner(this)
        val effects = listOf("Robot", "Deep", "Monster", "Baby", "Cartoon")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, effects)
        spinner.setSelection(0)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selected = effects[position]
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        val start = Button(this).apply {
            text = "START VOICE EFFECT"
            setOnClickListener { startAudio() }
        }
        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener { stopAudio() }
        }
        val note = TextView(this).apply {
            text = "Important: This demo changes microphone audio and plays it through your phone/headset. Android does not let an ordinary app inject this audio into Free Fire's in-game microphone. Use a headset and keep volume low to avoid feedback."
            textSize = 13f; setTextColor(Color.rgb(210, 205, 225)); setPadding(0, 24, 0, 0)
        }
        layout.addView(title); layout.addView(subtitle); layout.addView(status)
        layout.addView(label); layout.addView(spinner)
        layout.addView(start); layout.addView(stop); layout.addView(note)
        setContentView(layout)
    }

    private fun startAudio() {
        if (running) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            status.text = "Status: Allow microphone permission, then press Start"
            return
        }
        val minIn = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0 || minOut <= 0) { status.text = "Audio device unavailable"; return }
        try {
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minIn, 4096))
            player = AudioTrack(AudioManager.STREAM_MUSIC, sampleRate,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                max(minOut, 4096), AudioTrack.MODE_STREAM)
            recorder?.startRecording()
            player?.play()
            running = true
            status.text = "Status: Live effect running — $selected"
            thread(name = "VoiceEffectAudio") {
                val input = ShortArray(1024)
                var phase = 0.0
                while (running) {
                    val count = recorder?.read(input, 0, input.size) ?: 0
                    if (count > 0) {
                        val output = ShortArray(count)
                        for (i in 0 until count) {
                            val x = input[i].toDouble() / 32768.0
                            val y = when (selected) {
                                "Robot" -> x * (if (sin(phase).toInt() == 0) 0.65 else 1.0)
                                "Deep" -> x * 0.78
                                "Monster" -> (x * 1.35).coerceIn(-1.0, 1.0)
                                "Baby" -> (x * 1.12).coerceIn(-1.0, 1.0)
                                else -> (sin(x * 2.6) * 0.8)
                            }
                            phase += 2.0 * PI * 35.0 / sampleRate
                            output[i] = (y.coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort()
                        }
                        player?.write(output, 0, count)
                    }
                }
            }
        } catch (e: Exception) {
            running = false
            status.text = "Could not start audio: ${e.message ?: "unknown error"}"
            releaseAudio()
        }
    }

    private fun stopAudio() {
        running = false
        releaseAudio()
        status.text = "Status: Stopped"
    }

    private fun releaseAudio() {
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.stop() } catch (_: Exception) {}
        recorder?.release(); player?.release()
        recorder = null; player = null
    }

    override fun onDestroy() {
        stopAudio()
        super.onDestroy()
    }
}
